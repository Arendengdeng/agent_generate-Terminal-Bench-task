
import csv,json,subprocess,tempfile
from pathlib import Path
import pytest
CASES=[({}, []), ({'a': [], 'nested/a': [0, 255], '文 space': [0, 255], '.hidden': [97, 98, 99]}, [{'size': 2, 'sha256': '06eb7d6a69ee19e5fbdf749018d3d2abfa04bcbd1365db312eb86dc7169389b8', 'paths': ['nested/a', '文 space']}, {'size': 3, 'sha256': 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad', 'paths': ['.hidden']}, {'size': 0, 'sha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855', 'paths': ['a']}]), ({'f000': [97, 98, 99], 'f001': [97, 98, 99], 'f002': [97, 98, 99], 'f003': [97, 98, 99], 'f004': [97, 98, 99], 'f005': [97, 98, 99], 'f006': [97, 98, 99], 'f007': [97, 98, 99], 'f008': [97, 98, 99], 'f009': [97, 98, 99], 'f010': [97, 98, 99], 'f011': [97, 98, 99], 'f012': [97, 98, 99], 'f013': [97, 98, 99], 'f014': [97, 98, 99], 'f015': [97, 98, 99], 'f016': [97, 98, 99], 'f017': [97, 98, 99], 'f018': [97, 98, 99], 'f019': [97, 98, 99], 'f020': [97, 98, 99], 'f021': [97, 98, 99], 'f022': [97, 98, 99], 'f023': [97, 98, 99], 'f024': [97, 98, 99], 'f025': [97, 98, 99], 'f026': [97, 98, 99], 'f027': [97, 98, 99], 'f028': [97, 98, 99], 'f029': [97, 98, 99], 'f030': [97, 98, 99], 'f031': [97, 98, 99], 'f032': [97, 98, 99], 'f033': [97, 98, 99], 'f034': [97, 98, 99], 'f035': [97, 98, 99], 'f036': [97, 98, 99], 'f037': [97, 98, 99], 'f038': [97, 98, 99], 'f039': [97, 98, 99], 'f040': [97, 98, 99], 'f041': [97, 98, 99], 'f042': [97, 98, 99], 'f043': [97, 98, 99], 'f044': [97, 98, 99], 'f045': [97, 98, 99], 'f046': [97, 98, 99], 'f047': [97, 98, 99], 'f048': [97, 98, 99], 'f049': [97, 98, 99], 'f050': [97, 98, 99], 'f051': [97, 98, 99], 'f052': [97, 98, 99], 'f053': [97, 98, 99], 'f054': [97, 98, 99], 'f055': [97, 98, 99], 'f056': [97, 98, 99], 'f057': [97, 98, 99], 'f058': [97, 98, 99], 'f059': [97, 98, 99], 'f060': [97, 98, 99], 'f061': [97, 98, 99], 'f062': [97, 98, 99], 'f063': [97, 98, 99], 'f064': [97, 98, 99], 'f065': [97, 98, 99], 'f066': [97, 98, 99], 'f067': [97, 98, 99], 'f068': [97, 98, 99], 'f069': [97, 98, 99], 'f070': [97, 98, 99], 'f071': [97, 98, 99], 'f072': [97, 98, 99], 'f073': [97, 98, 99], 'f074': [97, 98, 99], 'f075': [97, 98, 99], 'f076': [97, 98, 99], 'f077': [97, 98, 99], 'f078': [97, 98, 99], 'f079': [97, 98, 99], 'f080': [97, 98, 99], 'f081': [97, 98, 99], 'f082': [97, 98, 99], 'f083': [97, 98, 99], 'f084': [97, 98, 99], 'f085': [97, 98, 99], 'f086': [97, 98, 99], 'f087': [97, 98, 99], 'f088': [97, 98, 99], 'f089': [97, 98, 99], 'f090': [97, 98, 99], 'f091': [97, 98, 99], 'f092': [97, 98, 99], 'f093': [97, 98, 99], 'f094': [97, 98, 99], 'f095': [97, 98, 99], 'f096': [97, 98, 99], 'f097': [97, 98, 99], 'f098': [97, 98, 99], 'f099': [97, 98, 99]}, [{'size': 3, 'sha256': 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad', 'paths': ['f000', 'f001', 'f002', 'f003', 'f004', 'f005', 'f006', 'f007', 'f008', 'f009', 'f010', 'f011', 'f012', 'f013', 'f014', 'f015', 'f016', 'f017', 'f018', 'f019', 'f020', 'f021', 'f022', 'f023', 'f024', 'f025', 'f026', 'f027', 'f028', 'f029', 'f030', 'f031', 'f032', 'f033', 'f034', 'f035', 'f036', 'f037', 'f038', 'f039', 'f040', 'f041', 'f042', 'f043', 'f044', 'f045', 'f046', 'f047', 'f048', 'f049', 'f050', 'f051', 'f052', 'f053', 'f054', 'f055', 'f056', 'f057', 'f058', 'f059', 'f060', 'f061', 'f062', 'f063', 'f064', 'f065', 'f066', 'f067', 'f068', 'f069', 'f070', 'f071', 'f072', 'f073', 'f074', 'f075', 'f076', 'f077', 'f078', 'f079', 'f080', 'f081', 'f082', 'f083', 'f084', 'f085', 'f086', 'f087', 'f088', 'f089', 'f090', 'f091', 'f092', 'f093', 'f094', 'f095', 'f096', 'f097', 'f098', 'f099']}])]
FAMILY='manifest'
ARTIFACT='/app/src/manifest.py'
KIND='complete'

@pytest.mark.parametrize('data,expected',CASES)
def test_public_cli(data,expected):
    with tempfile.TemporaryDirectory() as work:
        root=Path(work); source=root/'input'; target=root/'answer'
        if FAMILY=='manifest':
            source.mkdir(); (source/'empty-dir').mkdir()
            for name,content in data.items():
                p=source/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(bytes(content))
        elif FAMILY=='csv':
            with source.open('w',encoding='utf-8',newline='') as f:
                writer=csv.writer(f); writer.writerow(['email','name']); writer.writerows(data)
        else:
            source.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in data),encoding='utf-8')
        def snapshot():
            return {p.relative_to(root).as_posix():('directory' if p.is_dir() else p.read_bytes()) for p in root.rglob('*') if p!=target}
        before=snapshot()
        proc=subprocess.run(['python3',ARTIFACT,str(source),str(target)],capture_output=True,timeout=10)
        assert proc.returncode==0,proc.stderr
        assert target.is_file()
        if KIND=='omission': return
        raw=target.read_bytes()
        if FAMILY=='csv':
            with target.open(encoding='utf-8',newline='') as f: rows=list(csv.reader(f,strict=True))
            assert rows[0]==['email','name']
            assert rows[1:]==expected
        else:
            actual=json.loads(raw.decode('utf-8'))
            assert type(actual)==list
            assert all(type(r)==dict and set(r)==set(expected[0]) for r in actual) if expected else actual==[]
            assert actual==expected
        assert snapshot()==before
        if KIND=='overstrict':
            assert b'\r' not in raw if FAMILY=='csv' else raw.endswith(b'\n')
