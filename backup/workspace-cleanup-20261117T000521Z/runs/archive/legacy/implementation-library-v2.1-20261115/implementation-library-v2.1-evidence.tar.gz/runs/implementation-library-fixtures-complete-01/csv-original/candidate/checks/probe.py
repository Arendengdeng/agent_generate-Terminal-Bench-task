# Hand-authored fixture; not used as label evidence.
