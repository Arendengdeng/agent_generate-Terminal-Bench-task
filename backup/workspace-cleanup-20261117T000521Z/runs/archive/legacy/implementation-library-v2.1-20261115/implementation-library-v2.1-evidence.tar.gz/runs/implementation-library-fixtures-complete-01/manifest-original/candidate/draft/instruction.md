修复目录摘要 CLI，递归生成每个普通文件的相对路径、字节数和 SHA-256。
input_dir 是存在的目录，包含至多 100 个普通文件以及任意空目录，嵌套深度最多 8。文件可为空或为二进制，每个文件至多 1 MiB；名称是合法 Unicode，不含换行。无符号链接或特殊文件。output.json 位于输入目录外。
UTF-8 JSON 数组，每项恰含 path、size、sha256。path 是相对 input_dir 的 POSIX 路径，size 为内容字节数，sha256 为内容摘要的 64 位小写十六进制字符串。按 path 的 Python 字符串升序排列，忽略目录；空目录输出 []。