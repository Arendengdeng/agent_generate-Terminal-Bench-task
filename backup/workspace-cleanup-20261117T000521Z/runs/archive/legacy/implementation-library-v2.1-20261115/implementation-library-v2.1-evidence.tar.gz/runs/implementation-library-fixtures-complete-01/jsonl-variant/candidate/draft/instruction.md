修复 JSONL 聚合工具，仅按 service 分组，统计条数、总耗时及最大耗时。
UTF-8 JSONL，每行对象包含非空字符串 service、级别 INFO/WARN/ERROR 和非负整数 duration_ms。最多 1000 行；允许空文件，不包含空行或非法 JSON。
UTF-8 JSON 数组；每个实际出现的 service 对应一个对象，恰含 service、count、total_duration_ms、max_duration_ms。统计该服务所有级别的记录数、耗时之和及最大耗时。按 service 的 Python 字符串升序排列；空输入输出 []。