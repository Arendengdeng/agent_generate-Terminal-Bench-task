import json,sys,itertools,collections,bisect
with open(sys.argv[1],encoding='utf-8') as f: records=[json.loads(line) for line in f]
def key(r): return r['service']
out=[]
def emit(k,values):
    item={'service':k if True else k[0],'count':len(values),'total_duration_ms':sum(values)}
    if True: item['max_duration_ms']=max(values)
    else: item['level']=k[1]
    return item
keys=[]; buckets=[]
for r in records:
    k=key(r); i=bisect.bisect_left(keys,k)
    if i==len(keys) or keys[i]!=k: keys.insert(i,k); buckets.insert(i,[])
    buckets[i].append(r['duration_ms'])
out=[emit(k,v) for k,v in zip(keys,buckets)]
with open(sys.argv[2],'w',encoding='utf-8') as f: json.dump(out,f,ensure_ascii=False)
