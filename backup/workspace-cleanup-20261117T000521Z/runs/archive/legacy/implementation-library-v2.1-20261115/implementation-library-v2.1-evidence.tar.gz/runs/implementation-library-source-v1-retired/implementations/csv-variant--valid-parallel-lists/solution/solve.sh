#!/bin/sh
set -eu
python3 - <<'LIBRARY_INSTALL'
from pathlib import Path
p=Path('/app/clean.py'); p.parent.mkdir(parents=True,exist_ok=True); p.write_text("import csv,sys,itertools\nwith open(sys.argv[1],encoding='utf-8',newline='') as f:\n    pairs=[(r['email'].strip().lower(),r['name'].strip()) for r in csv.DictReader(f)]\nkeys=[]; values=[]\nfor key,value in pairs:\n    if key not in keys: keys.append(key); values.append(value)\n    elif True: values[keys.index(key)]=value\nout=list(zip(keys,values))\nwith open(sys.argv[2],'w',encoding='utf-8',newline='') as f:\n    writer=csv.writer(f); writer.writerow(['email','name']); writer.writerows(out)\n",encoding='utf-8')
LIBRARY_INSTALL
