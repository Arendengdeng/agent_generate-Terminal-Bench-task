# 实现评估库

`evaluation_library/v2.1` 覆盖 CSV、JSONL、manifest 的原任务与变体。每任务 5 个合法设计、9 个违规实现，共 84 个。实现来源是审查编写与受控变异，不是模型生成批次。

## 核验规则

`library.json` 和各实现 `review.json` 保存逐 Requirement 的**预期**标签、源码审查理由、Contract/源码/适配器/AST 摘要及来源。构建时审查状态为 `pending-execution`；它不表示标签已经确认。

独立见证保存在 `witnesses/`：固定锚点、小域枚举、固定种子样例、边界及变形样例。预期结果由独立规范代码与摘要锚点产生，不使用实现配方、任务 Oracle 或待评分测试。见证覆盖合法域中的空输入、Unicode、多行 CSV、大整数、二进制文件及数量/大小/深度边界。

核验只在真实 Docker 隔离环境执行代码。每次保存命令、退出码、stdout/stderr、原始输出、输入树前后快照、实际安装文件摘要和镜像 ID。输入快照须与见证一致，实际安装文件须与受审查源码一致。按 CSV/JSON 语义比较，接受允许的等价表示，同时检查字段、数值类型、顺序和编码。

每个 `task_id:Rn` 的实测结论为 `satisfied`、`violated` 或 `unresolved`，引用具体见证。复合 Requirement 只有全部检查通过且源码审查支持时才记为满足；任何已证实的子项失败都意味着该 Requirement 被违反。输出缺失/格式失败也可能同时违反依赖该输出的多项要求，因而违规标签不承诺只有一个受影响 Requirement。

合法标签要求所有 Requirement 的审查与实测一致；违规标签要求明确反例，且其他逐项标签也一致。基础设施错误、超时、不完整证据或预期标签冲突均保留未决。有限见证与源码审查不构成一般正确性证明。

## 目录与命令

需要 Python 3.11+、Linux Docker，以及已有的 `python:3.11-slim` 镜像。双后端评分另需仓库的 Harbor 0.25.0 环境与 `independent-verifier:pytest-9.2.0` 镜像。命令不读取模型密钥，不调用模型。

```bash
# 新建版本；目录必须不存在。现有 v2.1 可直接 validate/verify。
python3 -m independent_verification.implementation_library build --output evaluation_library/v3 --version v3
python3 -m independent_verification.implementation_library validate --library evaluation_library/v2.1

# 新目录运行；最多三个并行容器。
python3 -m independent_verification.implementation_library verify \
  --library evaluation_library/v2.1 --output runs/library-audit-NEW --workers 3

# 离线重算逐 Requirement 结论，并生成新的 JSON/Markdown 报告。
python3 -m independent_verification.implementation_library report \
  --library evaluation_library/v2.1 --evidence runs/library-audit-NEW \
  --output runs/library-report-NEW

# 导出某任务的全部 14 个已核验实现，兼容原生 controls-manifest。
python3 -m independent_verification.implementation_library export-panel \
  --library evaluation_library/v2.1 --evidence runs/library-audit-NEW \
  --task csv-original --output runs/library-panel-NEW

# 评分给定的冻结测试；Contract 和候选输入绑定必须匹配。
python3 -m independent_verification.implementation_library score \
  --library evaluation_library/v2.1 --evidence runs/library-audit-NEW \
  --task csv-original --candidate PATH/TO/CANDIDATE --tests PATH/TO/FROZEN-TESTS \
  --backend both --output runs/library-score-NEW
```

`report --scores runs/library-score-NEW` 可重复提供评分运行。它核对源码、见证、审查和运行文件的摘要，重新计算逐 Requirement 标签，并核对评分行与原始 Docker/Harbor 记录、原生 verifier 分类和冻结测试绑定。证据清单检测缺失、新增与修改；摘要不是防止恶意重签全部证据的身份签名。

所有输出目录不可覆盖。核验/评分完整时退出码为 0；未决或执行不完整为 1；设置/证据错误返回非零。`score.complete` 表示评分执行完整且后端一致，不表示测试没有误拒/漏检。已确认库的 `report.complete` 才表示 84 个标签全部得到核验。

## 可复用评分实验

```bash
python3 scripts/implementation_library/run_evaluation.py \
  --library evaluation_library/v2.1 --evidence runs/library-audit-NEW \
  --output runs/library-evaluation-NEW --workers 3 --backend both --diagnostic-backend docker \
  --historical-candidate step3_test_1112/frozen/candidate \
  --historical-tests runs/p0-fixed-panel-manual-20261115-013144/verification/challenge/frozen-tests
```

入口为六任务分别建立人工 `complete`、`overstrict`、`omission` 评分夹具，并可增加一个兼容的历史 CSV 冻结套件。`--kinds complete` 可选子集，`--tasks csv-original` 可选任务。示例只在 Docker 上执行两类诊断夹具；完整夹具及历史套件使用双后端。省略 `--diagnostic-backend` 则全部套件继承 `--backend`；`--backend docker` 可单独检查该后端。人工夹具和语义核验检查器分别编写，夹具不是标签证据；候选元数据明确记录人工来源。`complete` 应接受合法实现并拒绝违规实现，`overstrict` 应暴露误拒，`omission` 应暴露漏检。历史套件的实际缺陷只记录，不预设必须通过。

按套件/任务、后端、反馈或保留组分别报告误拒、漏检、正常评分和计划分母。error、timeout、not_run 保留在计划分母，不算成功拒绝；零分母比率为 null。不同套件与后端不混成成功率。

每任务反馈组 3 合法、5 违规，保留组 2 合法、4 违规。同一算法/变异家族在原任务和变体中保持同组。评分入口只评估冻结测试，不启动 Agent 或触发修复。已公开查看过的保留组不能继续声称是新的盲测；后续修复实验应重新选择保留材料与运行目录。

回归：

```bash
python3 -m unittest tests.test_implementation_library -v
```

实际完成数量和评分结果另见验收记录；文档中的命令或工具存在不构成运行证据。


## 版本与新增边界

当前交付版本为 v2.1，见证协议为 4。CSV 程序显式放宽标准库字段大小限制，JSONL 程序放宽十进制整数位数限制；glob 程序转义输入根目录中的模式字符。协议额外核验 200,000 字节的 CSV 字段、5001 位 JSON 整数、带空格及 glob 模式字符的输入路径和八层目录。

先前 v1/v1.1/v2 是保留的开发批次；新见证推翻了早期版本的部分合法标签，并纠正了 v2 一项分组 Requirement 标签。当前报告入口将旧协议标为未决，禁止导出为已确认面板。旧源文件、撤回见证和中断评分仍保存在 runs 中，不计入最终 84 个实现。

导出的审查面板使用无损 gzip 保存完整见证与运行记录，以符合原生清单和证据文件预算；`gzip.open(path, 'rt', encoding='utf-8')` 可读取。逐项结论和反例索引保持普通 JSON。Harbor 以一个包含全部实现的原生 dataset job 调度，最多三个并发 trial；逐 trial 仍独立检查任务身份、reward、verifier 报告和实际镜像 ID。


## 标签修订与原始执行复用

只有程序、Contract、分组、角色和全部见证输入/预期值保持一致，才允许用新语义检查点复核原始执行；代码或见证变化需要重新执行。以下入口不调用 Docker，不伪造新的运行：

```bash
python3 -m independent_verification.implementation_library reverify \
  --library evaluation_library/v2.1 \
  --previous-library runs/implementation-library-source-v2-retired \
  --previous-evidence runs/implementation-library-v2-audit-01 \
  --output runs/library-reverification-NEW
```

原生评分可通过 `report --allow-equivalent-scores` 显式关联到新审查版本。入口先重放原始评分，再逐实现核对 Contract、角色、分组、安装配方摘要及实际交付文件摘要。报告标为 `equivalent-code`，保留原始库/运行摘要；不把复核计为新的 CLI 或 Harbor 执行。默认禁止跨库版本关联。

最终验收与历史套件发现见 [验收记录](../../evaluation_library/ACCEPTANCE.md)。
