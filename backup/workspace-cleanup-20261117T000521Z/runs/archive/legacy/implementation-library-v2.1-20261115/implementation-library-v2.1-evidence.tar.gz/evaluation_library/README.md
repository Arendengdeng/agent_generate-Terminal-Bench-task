# 经核验的实现评估库

当前版本为 **v2.1**：六种 Contract，各 5 个合法、9 个违规实现，共 **84 个**。实现来自源码审查编写与受控变异。

- [实现、来源与逐 Requirement 预期标签](v2.1/library.json)
- [已核验标签与覆盖矩阵](verification-v2.1/report.md)
- [19 套冻结测试的评分与证据绑定](evaluation-v2.1/report.md)
- [验收结果与历史套件发现](ACCEPTANCE.md)
- [旧标签撤回及独立反例](review-history.json)
- [使用、重放和自动评估](../docs/guides/implementation-library.md)

84/84 标签获确认，未决 0；336 项 Requirement 结论均有源码审查及见证。原始核验执行了 3,864 次 CLI，覆盖 200,000 字节 CSV 字段、5001 位 JSON 整数、字面 glob 字符输入路径、八层目录及数量/大小边界。

v2.1 增强了 SHA 分组的逐 Requirement 检查。程序、Contract 和见证数据与 v2 完全相同，因此按摘要核对后重放原始记录；没有重复计入 CLI 执行。评分记录也逐实现核对实际交付文件、安装配方、Contract、角色和分组，并标明 `equivalent-code` 关联。

独立见证与源码审查支持有限核验，不构成对任意输入的一般正确性证明。生成数量、标签确认和测试质量评分是不同指标。

开发版本及原始记录保存在 runs。22 个旧“合法”标签被额外合法输入反例推翻；另修正一项负例的 Requirement 标签。它们不计入当前 84 个实现。历史 CSV 测试的一项漏检和一项后端差异也原样保留。
