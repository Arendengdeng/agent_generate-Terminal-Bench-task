# 实现评估库 v2.1 验收

交付 **84 个经核验的实现**：六种 Contract，每种 5 合法、9 违规，总计 30 合法、54 违规。标签未决为 0。实现来源是审查编写与受控变异，没有真实模型生成或模型验收声明。

## 标签与运行证据

- 336 项 Requirement 结论：233 满足、103 违反；[逐项索引](verification-v2.1/summary.json)。
- 原始独立核验共 3,864 次 CLI 执行，全部在真实 Docker 中观察；[原始运行](../runs/implementation-library-v2-audit-01/results.json)。
- v2.1 在路径覆盖之外检查 SHA 分组成员关系，修正 `manifest-variant--invalid-semantic` 的 R2：错误常量摘要不仅违反 R3，也合并不同内容，违反 R2。
- 程序、Contract、角色、分组及见证数据与 v2 完全一致；[复核来源与摘要](../runs/implementation-library-v2.1-reverification-01/provenance.json)。原始运行文件逐字节保留，不把重放计为新执行。
- 每种任务覆盖全部 Requirement；合法实现有源码审查和固定/枚举/生成/边界/变形见证；违规实现有合法输入上的具体反例。

见证包含空输入、引号与多行 CSV、Unicode、200,000 字节 CSV 字段、5001 位整数、重复记录、二进制与空文件、特殊输入路径、1000 条记录、100 个文件、八层目录和 1 MiB 文件。有限见证与源码审查不构成一般正确性证明。

## 冻结测试评分

[逐运行、后端和分组报告](evaluation-v2.1/report.md)，[原始批次](../runs/implementation-library-v2-evaluation-01/evaluation.json)。19 套计划评估全部执行；18 套人工诊断符合预期。历史套件有未决后端差异，因此原批次退出码为 1，不能称为全部通过。

下表汇总执行量及已观测错误类型；详细统计按每个任务/套件、后端和反馈/保留组分别保存，不混合计算成功率。

|套件|后端|计划对照|正常评分|合法误拒|违规漏检|执行错误|
|---|---|---:|---:|---:|---:|---:|
|六任务完整人工夹具|Docker|84|84|0|0|0|
|六任务完整人工夹具|Harbor|84|84|0|0|0|
|六任务过严人工夹具|Docker|84|84|30|0|0|
|六任务遗漏人工夹具|Docker|84|84|0|48|0|
|历史 CSV 冻结套件|Docker|14|13|0|1|1|
|历史 CSV 冻结套件|Harbor|14|14|0|1|0|

六任务完整夹具在两个后端均接受全部 30 个合法实现、正常拒绝全部 54 个违规实现；84 个对照逐项一致。过严夹具故意误拒合法实现，遗漏夹具故意漏检，结果验证评分器能区分这些问题。人工夹具不作为实现标签证据，也不构成真实模型验收。

98 个 Harbor trial 均记录了实际 task/verifier 镜像 ID。评分向新审查版本关联前，先重放原始报告，再核对实际交付文件、安装配方、Contract、角色及分组；19 套均以 `equivalent-code` 明确记录来源，原始记录未改写。

## 历史 CSV 套件发现

- 两个后端均漏检 `csv-original--invalid-encoding`；独立语义见证已确认其会损坏保留的 Unicode 姓名。
- `csv-original--invalid-damage` 在 Docker 中触发 `Verifier files changed during execution`，Harbor 正常评分为拒绝，形成一项后端差异。
- Docker 的原始完整性记录显示容器内 `fixtures/header_only.csv`、`fixtures/mixed.csv` 被修改；该套件直接把这些冻结输入交给 CLI。原始宿主套件保持不变。
- 这项 Docker error 留在计划分母中，未计为成功拒绝，也没有用 Harbor 的正常拒绝覆盖差异。原始冻结测试未被修复或替换。

[历史评分与逐实现记录](../runs/implementation-library-v2-evaluation-01/scores/historical--csv-original/score.json)。

## 回归与历史保留

最终源码回归 **227 项：212 通过，15 项外部检查按配置跳过**；[完整日志](../runs/implementation-library-v2.1-checks-01/unittest.log)。另有上述真实 Docker/Harbor 运行，未用模拟执行器代替。

[22 个旧标签撤回记录及 Requirement 修订](review-history.json)、[源码归档映射](retired-sources.json)。CSV/JSON 标准库默认解析限制和 glob 根路径问题已修正；旧源码、反例、评分失败与中断目录保留。当前报告拒绝把旧见证协议继续当作已确认标签。
