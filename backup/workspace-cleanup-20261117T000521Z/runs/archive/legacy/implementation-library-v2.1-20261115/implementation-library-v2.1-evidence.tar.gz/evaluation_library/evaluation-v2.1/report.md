# 实现评估库核验报告

已确认 **84/84**；未决 **0**。

Attributed source review plus finite independent semantic witnesses; not a proof over all legal programs or inputs.

|任务|已确认|未决|
|---|---:|---:|
|csv-original|14|0|
|csv-variant|14|0|
|jsonl-original|14|0|
|jsonl-variant|14|0|
|manifest-original|14|0|
|manifest-variant|14|0|

## 逐实现 Requirement 结论

|实现|分组|角色|确认|R1|R2|R3|R4|
|---|---|---|---|---|---|---|---|
|[csv-original--valid-ordered-map](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--valid-ordered-map/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[csv-original--valid-index-scan](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--valid-index-scan/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[csv-original--valid-sorted-groups](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--valid-sorted-groups/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[csv-original--valid-parallel-lists](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--valid-parallel-lists/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[csv-original--valid-reverse-selection](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--valid-reverse-selection/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[csv-original--invalid-omission](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--invalid-omission/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[csv-original--invalid-hardcode](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--invalid-hardcode/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[csv-original--invalid-encoding](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--invalid-encoding/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[csv-original--invalid-empty](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--invalid-empty/result.json>)|feedback|invalid|confirmed|violated|violated|violated|satisfied|
|[csv-original--invalid-damage](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--invalid-damage/result.json>)|feedback|invalid|confirmed|satisfied|satisfied|satisfied|violated|
|[csv-original--invalid-format](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--invalid-format/result.json>)|holdout|invalid|confirmed|violated|violated|violated|satisfied|
|[csv-original--invalid-order](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--invalid-order/result.json>)|holdout|invalid|confirmed|satisfied|violated|violated|satisfied|
|[csv-original--invalid-semantic](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--invalid-semantic/result.json>)|holdout|invalid|confirmed|satisfied|violated|violated|satisfied|
|[csv-original--invalid-limit](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-original--invalid-limit/result.json>)|holdout|invalid|confirmed|satisfied|violated|violated|satisfied|
|[csv-variant--valid-ordered-map](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--valid-ordered-map/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[csv-variant--valid-index-scan](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--valid-index-scan/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[csv-variant--valid-sorted-groups](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--valid-sorted-groups/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[csv-variant--valid-parallel-lists](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--valid-parallel-lists/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[csv-variant--valid-reverse-selection](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--valid-reverse-selection/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[csv-variant--invalid-omission](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--invalid-omission/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[csv-variant--invalid-hardcode](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--invalid-hardcode/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[csv-variant--invalid-encoding](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--invalid-encoding/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[csv-variant--invalid-empty](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--invalid-empty/result.json>)|feedback|invalid|confirmed|violated|violated|violated|satisfied|
|[csv-variant--invalid-damage](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--invalid-damage/result.json>)|feedback|invalid|confirmed|satisfied|satisfied|satisfied|violated|
|[csv-variant--invalid-format](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--invalid-format/result.json>)|holdout|invalid|confirmed|violated|violated|violated|satisfied|
|[csv-variant--invalid-order](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--invalid-order/result.json>)|holdout|invalid|confirmed|satisfied|violated|violated|satisfied|
|[csv-variant--invalid-semantic](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--invalid-semantic/result.json>)|holdout|invalid|confirmed|satisfied|violated|violated|satisfied|
|[csv-variant--invalid-limit](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/csv-variant--invalid-limit/result.json>)|holdout|invalid|confirmed|satisfied|violated|violated|satisfied|
|[jsonl-original--valid-stream-accumulator](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--valid-stream-accumulator/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[jsonl-original--valid-sorted-groupby](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--valid-sorted-groupby/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[jsonl-original--valid-filter-per-key](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--valid-filter-per-key/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[jsonl-original--valid-counter-and-sums](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--valid-counter-and-sums/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[jsonl-original--valid-incremental-buckets](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--valid-incremental-buckets/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[jsonl-original--invalid-omission](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--invalid-omission/result.json>)|feedback|invalid|confirmed|satisfied|violated|satisfied|satisfied|
|[jsonl-original--invalid-hardcode](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--invalid-hardcode/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[jsonl-original--invalid-encoding](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--invalid-encoding/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[jsonl-original--invalid-empty](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--invalid-empty/result.json>)|feedback|invalid|confirmed|violated|violated|violated|satisfied|
|[jsonl-original--invalid-damage](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--invalid-damage/result.json>)|feedback|invalid|confirmed|satisfied|satisfied|satisfied|violated|
|[jsonl-original--invalid-format](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--invalid-format/result.json>)|holdout|invalid|confirmed|violated|violated|violated|satisfied|
|[jsonl-original--invalid-order](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--invalid-order/result.json>)|holdout|invalid|confirmed|satisfied|satisfied|violated|satisfied|
|[jsonl-original--invalid-semantic](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--invalid-semantic/result.json>)|holdout|invalid|confirmed|satisfied|violated|satisfied|satisfied|
|[jsonl-original--invalid-limit](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-original--invalid-limit/result.json>)|holdout|invalid|confirmed|satisfied|violated|satisfied|satisfied|
|[jsonl-variant--valid-stream-accumulator](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--valid-stream-accumulator/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[jsonl-variant--valid-sorted-groupby](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--valid-sorted-groupby/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[jsonl-variant--valid-filter-per-key](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--valid-filter-per-key/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[jsonl-variant--valid-counter-and-sums](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--valid-counter-and-sums/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[jsonl-variant--valid-incremental-buckets](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--valid-incremental-buckets/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[jsonl-variant--invalid-omission](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--invalid-omission/result.json>)|feedback|invalid|confirmed|satisfied|violated|satisfied|satisfied|
|[jsonl-variant--invalid-hardcode](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--invalid-hardcode/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[jsonl-variant--invalid-encoding](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--invalid-encoding/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[jsonl-variant--invalid-empty](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--invalid-empty/result.json>)|feedback|invalid|confirmed|violated|violated|violated|satisfied|
|[jsonl-variant--invalid-damage](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--invalid-damage/result.json>)|feedback|invalid|confirmed|satisfied|satisfied|satisfied|violated|
|[jsonl-variant--invalid-format](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--invalid-format/result.json>)|holdout|invalid|confirmed|violated|violated|violated|satisfied|
|[jsonl-variant--invalid-order](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--invalid-order/result.json>)|holdout|invalid|confirmed|satisfied|satisfied|violated|satisfied|
|[jsonl-variant--invalid-semantic](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--invalid-semantic/result.json>)|holdout|invalid|confirmed|satisfied|violated|satisfied|satisfied|
|[jsonl-variant--invalid-limit](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/jsonl-variant--invalid-limit/result.json>)|holdout|invalid|confirmed|satisfied|violated|satisfied|satisfied|
|[manifest-original--valid-pathlib-whole](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--valid-pathlib-whole/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[manifest-original--valid-os-walk-chunks](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--valid-os-walk-chunks/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[manifest-original--valid-explicit-stack](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--valid-explicit-stack/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[manifest-original--valid-recursive-scandir](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--valid-recursive-scandir/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[manifest-original--valid-glob-memoryview](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--valid-glob-memoryview/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[manifest-original--invalid-omission](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--invalid-omission/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[manifest-original--invalid-hardcode](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--invalid-hardcode/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[manifest-original--invalid-encoding](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--invalid-encoding/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[manifest-original--invalid-empty](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--invalid-empty/result.json>)|feedback|invalid|confirmed|violated|violated|violated|satisfied|
|[manifest-original--invalid-damage](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--invalid-damage/result.json>)|feedback|invalid|confirmed|satisfied|satisfied|satisfied|violated|
|[manifest-original--invalid-format](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--invalid-format/result.json>)|holdout|invalid|confirmed|violated|violated|violated|satisfied|
|[manifest-original--invalid-order](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--invalid-order/result.json>)|holdout|invalid|confirmed|satisfied|satisfied|violated|satisfied|
|[manifest-original--invalid-semantic](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--invalid-semantic/result.json>)|holdout|invalid|confirmed|satisfied|satisfied|violated|satisfied|
|[manifest-original--invalid-limit](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-original--invalid-limit/result.json>)|holdout|invalid|confirmed|satisfied|violated|violated|satisfied|
|[manifest-variant--valid-pathlib-whole](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--valid-pathlib-whole/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[manifest-variant--valid-os-walk-chunks](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--valid-os-walk-chunks/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[manifest-variant--valid-explicit-stack](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--valid-explicit-stack/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[manifest-variant--valid-recursive-scandir](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--valid-recursive-scandir/result.json>)|feedback|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[manifest-variant--valid-glob-memoryview](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--valid-glob-memoryview/result.json>)|holdout|correct|confirmed|satisfied|satisfied|satisfied|satisfied|
|[manifest-variant--invalid-omission](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--invalid-omission/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[manifest-variant--invalid-hardcode](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--invalid-hardcode/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[manifest-variant--invalid-encoding](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--invalid-encoding/result.json>)|feedback|invalid|confirmed|satisfied|violated|violated|satisfied|
|[manifest-variant--invalid-empty](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--invalid-empty/result.json>)|feedback|invalid|confirmed|violated|violated|violated|satisfied|
|[manifest-variant--invalid-damage](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--invalid-damage/result.json>)|feedback|invalid|confirmed|satisfied|satisfied|satisfied|violated|
|[manifest-variant--invalid-format](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--invalid-format/result.json>)|holdout|invalid|confirmed|violated|violated|violated|satisfied|
|[manifest-variant--invalid-order](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--invalid-order/result.json>)|holdout|invalid|confirmed|satisfied|satisfied|violated|satisfied|
|[manifest-variant--invalid-semantic](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--invalid-semantic/result.json>)|holdout|invalid|confirmed|satisfied|violated|violated|satisfied|
|[manifest-variant--invalid-limit](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/implementations/manifest-variant--invalid-limit/result.json>)|holdout|invalid|confirmed|satisfied|violated|violated|satisfied|

## 冻结测试评分

标为 equivalent-code 的运行通过逐实现源码、实际交付文件、Contract、角色和分组校验复用原始执行；没有重新运行或覆盖历史记录。

按运行、后端、反馈/保留组分别计数；error、timeout、not_run 不计成功拒绝。
人工夹具只验证评分器，不构成模型生成或端到端验收。

|运行 / 任务|绑定|后端|分组|角色|计划|正常评分|误拒|漏检|error|timeout|未执行|
|---|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|
|complete--csv-original / csv-original|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|complete--csv-original / csv-original|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|complete--csv-original / csv-original|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|complete--csv-original / csv-original|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|complete--csv-original / csv-original|equivalent-code|harbor|feedback|correct|3|3|0|—|0|0|0|
|complete--csv-original / csv-original|equivalent-code|harbor|feedback|invalid|5|5|—|0|0|0|0|
|complete--csv-original / csv-original|equivalent-code|harbor|holdout|correct|2|2|0|—|0|0|0|
|complete--csv-original / csv-original|equivalent-code|harbor|holdout|invalid|4|4|—|0|0|0|0|
|complete--csv-variant / csv-variant|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|complete--csv-variant / csv-variant|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|complete--csv-variant / csv-variant|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|complete--csv-variant / csv-variant|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|complete--csv-variant / csv-variant|equivalent-code|harbor|feedback|correct|3|3|0|—|0|0|0|
|complete--csv-variant / csv-variant|equivalent-code|harbor|feedback|invalid|5|5|—|0|0|0|0|
|complete--csv-variant / csv-variant|equivalent-code|harbor|holdout|correct|2|2|0|—|0|0|0|
|complete--csv-variant / csv-variant|equivalent-code|harbor|holdout|invalid|4|4|—|0|0|0|0|
|complete--jsonl-original / jsonl-original|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|complete--jsonl-original / jsonl-original|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|complete--jsonl-original / jsonl-original|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|complete--jsonl-original / jsonl-original|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|complete--jsonl-original / jsonl-original|equivalent-code|harbor|feedback|correct|3|3|0|—|0|0|0|
|complete--jsonl-original / jsonl-original|equivalent-code|harbor|feedback|invalid|5|5|—|0|0|0|0|
|complete--jsonl-original / jsonl-original|equivalent-code|harbor|holdout|correct|2|2|0|—|0|0|0|
|complete--jsonl-original / jsonl-original|equivalent-code|harbor|holdout|invalid|4|4|—|0|0|0|0|
|complete--jsonl-variant / jsonl-variant|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|complete--jsonl-variant / jsonl-variant|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|complete--jsonl-variant / jsonl-variant|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|complete--jsonl-variant / jsonl-variant|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|complete--jsonl-variant / jsonl-variant|equivalent-code|harbor|feedback|correct|3|3|0|—|0|0|0|
|complete--jsonl-variant / jsonl-variant|equivalent-code|harbor|feedback|invalid|5|5|—|0|0|0|0|
|complete--jsonl-variant / jsonl-variant|equivalent-code|harbor|holdout|correct|2|2|0|—|0|0|0|
|complete--jsonl-variant / jsonl-variant|equivalent-code|harbor|holdout|invalid|4|4|—|0|0|0|0|
|complete--manifest-original / manifest-original|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|complete--manifest-original / manifest-original|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|complete--manifest-original / manifest-original|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|complete--manifest-original / manifest-original|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|complete--manifest-original / manifest-original|equivalent-code|harbor|feedback|correct|3|3|0|—|0|0|0|
|complete--manifest-original / manifest-original|equivalent-code|harbor|feedback|invalid|5|5|—|0|0|0|0|
|complete--manifest-original / manifest-original|equivalent-code|harbor|holdout|correct|2|2|0|—|0|0|0|
|complete--manifest-original / manifest-original|equivalent-code|harbor|holdout|invalid|4|4|—|0|0|0|0|
|complete--manifest-variant / manifest-variant|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|complete--manifest-variant / manifest-variant|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|complete--manifest-variant / manifest-variant|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|complete--manifest-variant / manifest-variant|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|complete--manifest-variant / manifest-variant|equivalent-code|harbor|feedback|correct|3|3|0|—|0|0|0|
|complete--manifest-variant / manifest-variant|equivalent-code|harbor|feedback|invalid|5|5|—|0|0|0|0|
|complete--manifest-variant / manifest-variant|equivalent-code|harbor|holdout|correct|2|2|0|—|0|0|0|
|complete--manifest-variant / manifest-variant|equivalent-code|harbor|holdout|invalid|4|4|—|0|0|0|0|
|historical--csv-original / csv-original|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|historical--csv-original / csv-original|equivalent-code|docker|feedback|invalid|5|4|—|1|1|0|0|
|historical--csv-original / csv-original|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|historical--csv-original / csv-original|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|historical--csv-original / csv-original|equivalent-code|harbor|feedback|correct|3|3|0|—|0|0|0|
|historical--csv-original / csv-original|equivalent-code|harbor|feedback|invalid|5|5|—|1|0|0|0|
|historical--csv-original / csv-original|equivalent-code|harbor|holdout|correct|2|2|0|—|0|0|0|
|historical--csv-original / csv-original|equivalent-code|harbor|holdout|invalid|4|4|—|0|0|0|0|
|omission--csv-original / csv-original|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|omission--csv-original / csv-original|equivalent-code|docker|feedback|invalid|5|5|—|4|0|0|0|
|omission--csv-original / csv-original|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|omission--csv-original / csv-original|equivalent-code|docker|holdout|invalid|4|4|—|4|0|0|0|
|omission--csv-variant / csv-variant|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|omission--csv-variant / csv-variant|equivalent-code|docker|feedback|invalid|5|5|—|4|0|0|0|
|omission--csv-variant / csv-variant|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|omission--csv-variant / csv-variant|equivalent-code|docker|holdout|invalid|4|4|—|4|0|0|0|
|omission--jsonl-original / jsonl-original|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|omission--jsonl-original / jsonl-original|equivalent-code|docker|feedback|invalid|5|5|—|4|0|0|0|
|omission--jsonl-original / jsonl-original|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|omission--jsonl-original / jsonl-original|equivalent-code|docker|holdout|invalid|4|4|—|4|0|0|0|
|omission--jsonl-variant / jsonl-variant|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|omission--jsonl-variant / jsonl-variant|equivalent-code|docker|feedback|invalid|5|5|—|4|0|0|0|
|omission--jsonl-variant / jsonl-variant|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|omission--jsonl-variant / jsonl-variant|equivalent-code|docker|holdout|invalid|4|4|—|4|0|0|0|
|omission--manifest-original / manifest-original|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|omission--manifest-original / manifest-original|equivalent-code|docker|feedback|invalid|5|5|—|4|0|0|0|
|omission--manifest-original / manifest-original|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|omission--manifest-original / manifest-original|equivalent-code|docker|holdout|invalid|4|4|—|4|0|0|0|
|omission--manifest-variant / manifest-variant|equivalent-code|docker|feedback|correct|3|3|0|—|0|0|0|
|omission--manifest-variant / manifest-variant|equivalent-code|docker|feedback|invalid|5|5|—|4|0|0|0|
|omission--manifest-variant / manifest-variant|equivalent-code|docker|holdout|correct|2|2|0|—|0|0|0|
|omission--manifest-variant / manifest-variant|equivalent-code|docker|holdout|invalid|4|4|—|4|0|0|0|
|overstrict--csv-original / csv-original|equivalent-code|docker|feedback|correct|3|3|3|—|0|0|0|
|overstrict--csv-original / csv-original|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|overstrict--csv-original / csv-original|equivalent-code|docker|holdout|correct|2|2|2|—|0|0|0|
|overstrict--csv-original / csv-original|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|overstrict--csv-variant / csv-variant|equivalent-code|docker|feedback|correct|3|3|3|—|0|0|0|
|overstrict--csv-variant / csv-variant|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|overstrict--csv-variant / csv-variant|equivalent-code|docker|holdout|correct|2|2|2|—|0|0|0|
|overstrict--csv-variant / csv-variant|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|overstrict--jsonl-original / jsonl-original|equivalent-code|docker|feedback|correct|3|3|3|—|0|0|0|
|overstrict--jsonl-original / jsonl-original|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|overstrict--jsonl-original / jsonl-original|equivalent-code|docker|holdout|correct|2|2|2|—|0|0|0|
|overstrict--jsonl-original / jsonl-original|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|overstrict--jsonl-variant / jsonl-variant|equivalent-code|docker|feedback|correct|3|3|3|—|0|0|0|
|overstrict--jsonl-variant / jsonl-variant|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|overstrict--jsonl-variant / jsonl-variant|equivalent-code|docker|holdout|correct|2|2|2|—|0|0|0|
|overstrict--jsonl-variant / jsonl-variant|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|overstrict--manifest-original / manifest-original|equivalent-code|docker|feedback|correct|3|3|3|—|0|0|0|
|overstrict--manifest-original / manifest-original|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|overstrict--manifest-original / manifest-original|equivalent-code|docker|holdout|correct|2|2|2|—|0|0|0|
|overstrict--manifest-original / manifest-original|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|
|overstrict--manifest-variant / manifest-variant|equivalent-code|docker|feedback|correct|3|3|3|—|0|0|0|
|overstrict--manifest-variant / manifest-variant|equivalent-code|docker|feedback|invalid|5|5|—|0|0|0|0|
|overstrict--manifest-variant / manifest-variant|equivalent-code|docker|holdout|correct|2|2|2|—|0|0|0|
|overstrict--manifest-variant / manifest-variant|equivalent-code|docker|holdout|invalid|4|4|—|0|0|0|0|

## 证据

- 实现库：[v2.1](</home/zyl/projects/agent_generate Terminal Bench task/evaluation_library/v2.1/library.json>)
- 原始核验：[implementation-library-v2.1-reverification-01](</home/zyl/projects/agent_generate Terminal Bench task/runs/implementation-library-v2.1-reverification-01/results.json>)
