Top-level readme (placeholder).
